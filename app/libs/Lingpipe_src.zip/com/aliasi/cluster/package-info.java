/**
 * Classes for clustering data and evaluation.
 */
package com.aliasi.cluster;
