/**
 * Classes for extracting meaningful chunks (spans) of text.
 */
package com.aliasi.chunk;


