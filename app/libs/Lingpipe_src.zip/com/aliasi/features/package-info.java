/**
 * Classes for extracting feature vectors from objects and parsing
 * objects for feature handlers.
 */
package com.aliasi.features;
