/**
 * Classes for matching and killing functions.
 */
package com.aliasi.coref.matchers;
