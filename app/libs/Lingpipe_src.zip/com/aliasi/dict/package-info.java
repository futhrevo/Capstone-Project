/**
 * Classes for handling dictionaries.
 */
package com.aliasi.dict;
