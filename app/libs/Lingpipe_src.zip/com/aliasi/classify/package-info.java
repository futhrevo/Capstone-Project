/**
 * Classes for classifying data and evaluation.  Throughout, we use
 * the term &quot;category&quot; rather than &quot;class&quot; or
 * &quot;type&quot;, to avoid confusion with the object-oriented
 * notion of class in Java.
*/
package com.aliasi.classify;

