/**
 * Classes for spelling correction and edit distance.
 */
package com.aliasi.spell;